<?php

// conectando com a database
$conn = mysqli_connect("localhost", "root", "", "bot") or die("Database Error");

// recebendo a mensagem do usuário por meio de ajax
$getMesg = mysqli_real_escape_string($conn, $_POST['text']);

// verificar a consulta do usuário para a consulta do banco de dados
$check_data = "SELECT replies FROM chatbot WHERE queries LIKE '%$getMesg%'";
$run_query = mysqli_query($conn, $check_data) or die("Error");



/* se a consulta do usuário corresponder à consulta do banco de dados, mostrará a resposta,
caso contrário, ele irá para o else */
if(mysqli_num_rows($run_query) > 0){

    //buscar reprodução do banco de dados de acordo com a consulta do usuário
    $fetch_data = mysqli_fetch_assoc($run_query);

    //armazenar a resposta a uma variável que enviaremos para ajax
    $replay = $fetch_data['replies'];
    echo $replay;

}
switch($getMesg){

    case 1:
        echo "ok, então vc já nos conhece, vamos lá...<br>";
        echo "Qual sua plataforma de streaming:<br><br>
        1 - Netflix <br>2 - HBO GO <br>3 - Prime video <br>4 - Globoplay";
    break;

    case 2:
        echo "ok, então vamos lá...";
    break;

    default:
        echo "Desculpa, não entendi.";


}



// elseif($getMesg == 'sim' || $getMesg == 1){
//     echo "ok, então vc já nos conhece, vamos lá...<br>";
//     echo "Qual sua plataforma de streaming:<br><br>
//     1 - Netflix <br>2 - HBO GO <br>3 - Prime video <br>4 - Globoplay";

   
// }

// if($getMesg == 'netflix'){
//     echo "ok, netflix";
// }

// elseif($getMesg == 'não' || $getMesg == 'nao' || $getMesg == 'n' ){
//     echo "ok, então vamos lá...";
   

// }
// else{
//     echo "Desculpa, não entendi.";
// }

?>
